<?php

namespace Martin\Web\User;

class UserManager {

	private $mailer;

	public function __construct(\Martin\Web\Service\Mailer $mailer) {
		$this->mailer = $mailer;
	}

	function getUsers() {
		return [[
			'name' => 'Ailish',
			'email' => 'martin.lejko@cuni.cz'
		]];
	}

	public function notifyUsers($content){
		$users = $this->getUsers();
		foreach ($users as $user) {
			$this->mailer->mail($user, $content);
		}
	}
}
