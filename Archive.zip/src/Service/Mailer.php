<?php

namespace Martin\Web\Service;

class Mailer {
    public function mail($email, $content) {
        print("Sending email to $email with content: $content\n");
    }
}