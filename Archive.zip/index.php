<?php
require __DIR__. '/vendor/autoload.php';

$builder = new DI\ContainerBuilder();
$container = $builder->build();

$manager = $container->get('Martin\Web\User\UserManager');
$users = $manager->getUsers();

print("Hello World\n");
print_r($users);